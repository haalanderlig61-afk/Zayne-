# WhatsApp Bot Node.js

Bot WhatsApp berbasis Node.js yang dijalankan menggunakan sistem pairing code.

---

## Syarat Wajib

- Node.js versi 23 ke atas
- npm
- Jalankan di Panel / Termux
- Nomor WhatsApp (untuk pairing)
- Koneksi internet stabil

---

## Cara Memulai Bot nya

- Tungu sinkronisasi selesai pada bot
- Ketik .menu dimana ada nomor bot nya
- Bot support di grub
- Bot Support Whatapp Bussiness

---

## Made By

- Senq Edogawa (Dev Syera, Miyano)
- 56578308861965 Dev (Shadow Empire)
- Ryuu (Support)